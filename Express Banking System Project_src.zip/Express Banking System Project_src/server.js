const express = require('express');
const app = express();
const port = 3000;

app.use(express.json());

let accounts = [];
let accountCounter = 10001;

const generateAccountNo = () => (accountCounter++).toString();

// --- Create Account Endpoint --- //
app.post('/createAccount', (req, res) => {
    const { name, email, initialDeposit } = req.body;
    if (!name || !email || typeof initialDeposit !== 'number' || initialDeposit < 0) {
        return res.status(400).json({ error: 'Invalid account data' });
    }

    const accountNo = generateAccountNo();
    const newAccount = {
        accountNo,
        name,
        email,
        balance: initialDeposit,
        transactions: []
    };

    accounts.push(newAccount);

    return res.status(201).json({
        message: "Account Created",
        "account No": accountNo
    });
});

// --- View Balance --- //
app.get('/balance/:accountNo', (req, res) => {
    const { accountNo } = req.params;
    const account = accounts.find(acc => acc.accountNo == accountNo);
    if (!account) {
        return res.status(404).json({ error: 'Account not found' });
    }

    return res.status(200).json({ amount: account.balance });
});


// --- Transfer Money --- //
app.post('/transfer', (req, res) => {
    const { fromAcct, toAcct, amount } = req.body;

    if (!fromAcct || !toAcct || typeof amount !== 'number' || amount <= 0) {
        return res.status(400).json({ error: 'Invalid transfer data' });
    }

    const fromAccount = accounts.find(acc => acc.accountNo == fromAcct);
    const toAccount = accounts.find(acc => acc.accountNo == toAcct);

    if (!fromAccount) {
        return res.status(404).json({ error: 'From account not found' });
    }
    if (!toAccount) {
        return res.status(404).json({ error: 'To account not found' });
    }

    if (fromAccount.balance < amount) {
        return res.status(400).json({ error: 'Insufficient funds' });
    }

    fromAccount.balance -= amount;
    toAccount.balance += amount;

    fromAccount.transactions.push({ type: 'debit', amount, to: toAcct, date: new Date() });
    toAccount.transactions.push({ type: 'credit', amount, from: fromAcct, date: new Date() });

    return res.status(200).json({ message: "transfer done" });
});

// --- Record the Transaction History --- //
app.get('/transaction/:accountNo', (req, res) => {
    const { accountNo } = req.params;
    const account = accounts.find(acc => acc.accountNo == accountNo);

    if (!account) {
        return res.status(404).json({ error: 'Account not found' });
    }

    if (account.transactions.length === 0) {
        return res.json({ message: "No transactions yet" });
    }

    const lastTx = account.transactions[account.transactions.length - 1];
    return res.json({
        message: `transaction happened successfully with ${lastTx.to || lastTx.from} with ${lastTx.amount}`
    });
});

// ---  Start Server --- //
app.listen(port, () => {
    console.log(` Express Banking server running on http://localhost:${port}`);
});